#include "Program.h" // Include Program.h for access to Program class and related functionalities.
#include "Input.h" // Include Input.h for InputCommand class definition.

//--------Teammember 3 to complete this section (class declaration) ----------
#include <iostream> // Include for input-output stream operations.
#include <string> // Include the standard string class.
#include <limits> // Include for numeric limits used in input validation.

extern std::map<std::string, double> variables; // Externally define the variables map.
extern int nextLine; // Extern declaration for the next line to execute, managed in Program.
extern bool conditionMetGlobal; // Extern declaration for a flag indicating if a condition was met.

// Constructor implementation. Initializes InputCommand with a variable name and reference to the variables map.
InputCommand::InputCommand(const std::string& var, std::map<std::string, double>& vars) : variable(var), variables(vars) {}

// Implements the input operation. Prompts the user for a value and stores it in the variables map.
void InputCommand::run() {
    double value; // Temporary storage for the user's input.
    std::cout << "Enter value for " << variable << ": "; // Prompt the user for input.

    while (true) { // Infinite loop until valid input is received.
        if (std::cin >> value) { // Try to read a double value from the user.
            variables[variable] = value; // If successful, store it in the map.
            break; // Exit the loop on successful input.
        } else { // If the input is invalid,
            std::cin.clear(); // clear the error flag on cin,
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // and ignore the rest of the line.
            std::cout << "Invalid input. Please enter a numeric value for " << variable << ": "; // Reprompt for input.
        }
    }
}

//----------------------------------------------------------------------------
