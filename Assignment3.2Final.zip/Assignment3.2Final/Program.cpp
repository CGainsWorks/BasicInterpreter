// Includes necessary headers for functionality.
#include "Program.h"
#include <sstream> // For parsing input lines into components.
#include <iostream> // For input/output operations.
#include <limits> // For handling input errors.

// Global variable declarations.
std::map<std::string, double> variables; // Maps variable names to their values for the program.
int nextLine = -1; // Indicates the next command line to jump to, if any.
bool conditionMetGlobal = false; // Tracks the state of the last evaluated condition.

// Static member definitions.
int Program::currentCommandIndex = 0;
std::map<int, int> Program::lineToCommandIndex;

// Constructor: initializes the Program object. It's empty because the initialization is straightforward.
Program::Program() = default;

// Destructor: cleans up allocated Command objects to prevent memory leaks.
Program::~Program() {
    for (auto cmd : commands) {
        delete cmd;
    }
}
// Parses a single line of input into a command object and stores it in the commands vector.
void Program::parseLine(const std::string& line) {
    std::istringstream iss(line);
    int lineNumber;
    std::string commandType;
    iss >> lineNumber >> commandType;
    // Depending on the command type, creates a new command object and adds it to the commands vector.
    // Supported commands: PRINT, LET, INPUT, GOTO, IF
    if (commandType == "PRINT") {
        std::string argument;
        getline(iss >> std::ws, argument);
        commands.push_back(new PrintCommand(argument, variables));
    } else if (commandType == "LET") {
        std::string variable, equals, expression;
        iss >> variable >> equals;
        getline(iss >> std::ws, expression);
        commands.push_back(new LetCommand(variable, expression, variables));
    } else if (commandType == "INPUT") {
        std::string variable;
        iss >> variable;
        commands.push_back(new InputCommand(variable, variables));
    } else if (commandType == "GOTO") {
        int targetLine;
        iss >> targetLine;
commands.push_back(new GotoCommand(targetLine));

    } else if (commandType == "IF") {
        std::string lhs, op, rhs;
        int lineToJump;
        iss >> lhs >> op >> rhs >> lineToJump;
        commands.push_back(new IfCommand(lhs, op[0], rhs, lineToJump, variables));
    }
    lineToCommandIndex[lineNumber] = commands.size() - 1;
}

// Executes the program by iterating over the commands vector and invoking each command's run method.
void Program::run() {
    currentCommandIndex = 0;
    bool isSkipping = false; // Used to skip commands when an IF condition is not met.
    
    // Loops through all commands in the program.
    while (currentCommandIndex < commands.size()) {
        Command* cmd = commands[currentCommandIndex];
        
        // Special handling for IF and GOTO commands.
        // IF commands may set isSkipping based on the condition's outcome.
        // GOTO commands change the flow of execution by modifying currentCommandIndex.
        if (auto ifCmd = dynamic_cast<IfCommand*>(cmd)) {
            cmd->run(); // Evaluate the IF condition
            isSkipping = !conditionMetGlobal; // If the condition is false, start skipping commands
        } else if (isSkipping) {
            // Continue skipping commands until we reach a command that should stop the skipping
            
            // If we encounter a command that logically serves as an 'ENDIF' (like a GOTO or the last command of IF block),
            // we stop skipping commands. Determining such a command might depend on your program's logic.
            
            // For simplicity, let's assume the next GOTO or the end of IF block resets skipping
            // but make sure to implement a proper check for the end of the IF block.
            if (dynamic_cast<GotoCommand*>(cmd)) {
                isSkipping = false; // Reset skipping on GOTO command, assuming it's like reaching an 'ENDIF'
            }
        } else {
            cmd->run(); // Execute the command if not skipping
        }

        // After running the command, handle any jumps due to GOTO
        if (nextLine != -1) {
            currentCommandIndex = nextLine; // Jump to the specified line
            nextLine = -1; // Reset for the next GOTO, if any
            isSkipping = false; // Reset skipping after a jump
        } else {
            ++currentCommandIndex; // Move to the next command
        }
    }
}



// Allows reading a program from an input stream (e.g., a file).
std::istream& operator>>(std::istream& in, Program& prog) {
    std::string line;
    while (getline(in, line)) {
        prog.parseLine(line);
    }
    return in;
}

