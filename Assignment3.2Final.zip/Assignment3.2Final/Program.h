#ifndef BASIC_PROGRAM_H // Include guard to prevent multiple inclusions.
#define BASIC_PROGRAM_H

#include <vector> // For storing a list of commands dynamically.
#include <string> // For handling text operations, necessary for parsing.
#include <map>    // For storing variables and their values.
#include <fstream> // For file I/O operations.
// Includes for different command types that the program can execute.
#include "Command.h"
#include "Print.h"
#include "Let.h"
#include "Input.h"
#include "Goto.h"
#include "If.h"

extern bool conditionMetGlobal; // External variable declaration to manage conditionals across files.

class Program {
private:
    std::vector<Command*> commands; // Stores pointers to Command objects representing the program instructions.
    std::map<std::string, double> variables; // Maps variable names to their values, accessible throughout the program.

public:
    static int currentCommandIndex; // Tracks the current position within the commands vector during execution.
    static std::map<int, int> lineToCommandIndex; // Maps line numbers to their corresponding positions in the commands vector.

    Program(); // Constructor declaration.
    ~Program(); // Destructor declaration. Cleans up allocated Command objects.

    void parseLine(const std::string& line); // Parses a single line of BASIC code into a command object.
    void run(); // Executes the program by iterating through the command objects and invoking their run method.

    // Overloads the extraction operator to read the program from an input stream (e.g., a file).
    friend std::istream& operator>>(std::istream& in, Program& prog);
};

#endif // BASIC_PROGRAM_H

