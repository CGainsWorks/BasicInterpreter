#ifndef GOTO_H // Begin of the include guard
#define GOTO_H

#include "Command.h" // Include the base class Command's definition

class GotoCommand : public Command { // Declaration of GotoCommand class inheriting from Command
    int targetLineNumber; // Private member variable to store the line number to go to

public:
    explicit GotoCommand(int line); // Constructor declaration with an explicit keyword to prevent automatic type conversion
    void run() override; // Override of the virtual run function from Command class
};

#endif // GOTO_H
// End of the include guard

