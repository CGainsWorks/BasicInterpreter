#include "Print.h" // Includes the header file for the PrintCommand class definition.
#include <iostream> // Includes the standard I/O header for output operations.

// Constructor: Initializes the PrintCommand with the argument to print and the variables map.
PrintCommand::PrintCommand(const std::string& arg, std::map<std::string, double>& vars) 
    : argument(arg), variables(vars) {}

// run method: Executes the print command.
void PrintCommand::run() {
    // Checks if the argument exists in the variables map.
    auto it = variables.find(argument);
    if (it != variables.end()) {
        std::cout << it->second << std::endl; // If found, print the variable's value.
    } else {
        std::cout << argument << std::endl; // If not found, treat the argument as a literal and print it.
    }
}

