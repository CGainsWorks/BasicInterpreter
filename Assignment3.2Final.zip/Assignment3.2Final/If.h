#ifndef BASIC_IF_H // Begin of the include guard.
#define BASIC_IF_H

#include "Command.h" // Includes the base class 'Command' to inherit from.
#include <string> // Includes the string library for using std::string.
#include <map> // Includes the map library to use std::map.

// Declaration of the IfCommand class that inherits from Command.
class IfCommand : public Command {
    std::string lhs; // Left-hand side operand of the conditional expression.
    char op; // Operator for the conditional expression (e.g., '=', '<', etc.).
    std::string rhs; // Right-hand side operand of the conditional expression.
    int targetLine; // Line number to jump to if the condition is true.
    std::map<std::string, double>& variables; // Reference to a map of variables available in the program.

public:
    // Constructor to initialize an IfCommand with its operands, operator, target line, and variables map.
    IfCommand(const std::string& lhs, char op, const std::string& rhs, int targetLine, std::map<std::string, double>& vars);
    void run() override; // Overrides the run method from the Command base class.
};

#endif // BASIC_IF_H
// End of the include guard.

