// Include guard to prevent multiple inclusions of this header file
#ifndef BASIC_LET_H
#define BASIC_LET_H

#include "Command.h" // Include the base Command class definition
#include <sstream>   // Include the stringstream header for string manipulation

// Additional includes for string processing
#include <string> // Standard string class for handling text data

// The LetCommand class inherits from Command, making it a specific type of command
class LetCommand : public Command {
    std::string variable; // Stores the name of the variable to which the expression's result will be assigned
    std::string expression; // Holds the arithmetic expression as a string to be evaluated
    std::map<std::string, double>& variables; // Reference to a map of variables managed by the Program class

public:
    // Constructor that takes the name of the variable, the arithmetic expression, and a reference to the variables map
    LetCommand(const std::string& var, const std::string& expr, std::map<std::string, double>& vars);

    // Overrides the run method from the Command class. This method will evaluate the expression and assign the result to the variable
    void run() override;
};

#endif // Ends the include guard

