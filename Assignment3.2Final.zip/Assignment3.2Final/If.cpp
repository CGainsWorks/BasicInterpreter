#include "If.h" // Includes the header file for the class definition.
#include <iostream> // Includes the IO library for debugging outputs.

extern std::map<std::string, double> variables; // Extern declaration for accessing global variables map.
extern bool conditionMetGlobal; // A global flag to indicate whether the condition was met.
extern int nextLine; // Used for handling GOTO within IF.

// Constructor implementation initializes the command with its operands, operator, target line, and the reference to the variables map.
IfCommand::IfCommand(const std::string& lhs, char op, const std::string& rhs, int targetLine, std::map<std::string, double>& vars)
    : lhs(lhs), op(op), rhs(rhs), targetLine(targetLine), variables(vars) {}

// Implements the run method to evaluate the if condition and perform actions accordingly.
void IfCommand::run() {
    double lhsValue = variables[lhs]; // Retrieves the value of the left-hand side variable.
    double rhsValue = variables.count(rhs) ? variables[rhs] : std::stod(rhs); // Tries to get the value of the right-hand side from variables; if not found, converts rhs to a double.

    conditionMetGlobal = false; // Defaults the condition to false.

    switch (op) {
        case '=': // Equal to - Checks if the operator is equal to '='.
            conditionMetGlobal = (lhsValue == rhsValue);// Sets conditionMetGlobal to true if lhs and rhs are equal.
            break;
        case '<': // Less than
            conditionMetGlobal = (lhsValue < rhsValue);
            break;
        case '>': // Greater than
            conditionMetGlobal = (lhsValue > rhsValue);
            break;
        // Additional cases for '!=', '<=', '>='
        case '!': // Not equal to, assuming '!' is used in this context
            conditionMetGlobal = (lhsValue != rhsValue);
            break;
        case 'L': // Placeholder for less than or equal to
            conditionMetGlobal = (lhsValue <= rhsValue);
            break;
        case 'G': // Placeholder for greater than or equal to
            conditionMetGlobal = (lhsValue >= rhsValue);
            break;
        default:
            std::cerr << "Unsupported conditional operator: " << op << std::endl;
    }



    // Debugging output commented out for clarity and brevity.
    // If the condition is not met and a target line is specified, it's handled in the program execution logic.
}

