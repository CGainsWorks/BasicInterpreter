// Include the definition of the Program class
#include "Program.h"
// Include file stream functionality to read from files
#include <fstream>

// The main function - entry point of the program
int main(int argc, char** argv) {
    // Check if exactly one argument is passed (excluding the program name)
    if (argc == 1) {
        // Print an error message if no input file is provided
        std::cerr << "You must pass an input file as a commandline argument. Correct usage is:\n"
                  << argv[0] << " infilename" << std::endl;
        // Exit the program with an error status
        exit(1);
    }

    // Create an input file stream and attempt to open the file provided as argument
    std::ifstream in(argv[1]);
    // Check if the file stream did not open correctly
    if (!in.good()) {
        // Print an error message if the file cannot be opened
        std::cerr << "Failed to open file at " << argv[1] << std::endl;
        // Exit the program with an error status
        exit(1);
    }

    // Create an instance of the Program class
    Program prog;
    // Use the overloaded operator >> to read from the file into the Program instance
    in >> prog;
    // Close the input file stream as it's no longer needed
    in.close();

    // Execute the logic defined in the Program instance
    prog.run();

    // Return a success status
    return 0;
}

