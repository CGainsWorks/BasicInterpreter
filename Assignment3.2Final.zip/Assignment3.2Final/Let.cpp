#include "Program.h" // Includes the Program header for access to program-related utilities and globals.
#include "Let.h" // Includes the LetCommand class definition.

//--------Teammember 3 to complete this section (class declaration) ----------
#include <iostream> // For debugging output.
#include <sstream> // For parsing the expression.
#include <algorithm> // For std::find_if_not used in trimming.
#include <cctype> // For character type checking in trimming functions.
#include <cmath> // For pow function

// These external variables are defined elsewhere and are used to track the program state and variables.
extern std::map<std::string, double> variables; // Holds variable names and their values.
extern int nextLine; // Used for jump instructions (not directly relevant to LetCommand).
extern bool conditionMetGlobal; // Tracks the state of condition checks (not directly relevant to LetCommand).

// Utility function to remove leading and trailing whitespace from a string.
std::string trim(const std::string& str) {
    auto start = str.find_first_not_of(" \t\n"); // Find the first non-whitespace character.
    auto end = str.find_last_not_of(" \t\n"); // Find the last non-whitespace character.
    return start == std::string::npos ? "" : str.substr(start, end - start + 1); // Return the trimmed string.
}

// LetCommand constructor initializes the object with the variable to be assigned to and the expression.
LetCommand::LetCommand(const std::string& var, const std::string& expr, std::map<std::string, double>& vars)
    : variable(var), expression(expr), variables(vars) {}

// The run method evaluates the mathematical expression and assigns the result to the specified variable.
void LetCommand::run() {
    std::string trimmedExpr = trim(expression); // Removes whitespace from the expression for parsing.
    double result = 0;
    char op;
    std::string lhs, rhs;

    std::istringstream iss(trimmedExpr); // Used to parse the expression string.
    if (iss >> lhs >> op >> rhs) { // Attempts to parse an expression of the form "lhs op rhs".
        double lhsVal = (variables.find(lhs) != variables.end()) ? variables[lhs] : std::stod(lhs); // Get or parse lhs value.
        double rhsVal = (variables.find(rhs) != variables.end()) ? variables[rhs] : std::stod(rhs); // Get or parse rhs value.

        // Switch based on the operator to perform the corresponding mathematical operation.
        switch (op) {
            case '+': result = lhsVal + rhsVal; break;
            case '-': result = lhsVal - rhsVal; break;
            case '*': result = lhsVal * rhsVal; break;
            case '/': // Division requires checking for division by zero.
                if(rhsVal != 0) {
                    result = lhsVal / rhsVal;
                } else {
                    std::cerr << "[ERROR] Division by zero in expression: " << trimmedExpr << std::endl;
                    return; // Abort the operation to prevent division by zero.
                }
                break;
            case '^': result = std::pow(lhsVal, rhsVal); break; // Exponentiation using std::pow.
            default:
                std::cerr << "[DEBUG] Unsupported operation in expression: " << trimmedExpr << std::endl;
                return; // Abort if the operator is not recognized.
        }

        variables[variable] = result; // Assign the result to the variable.
    } else {
        std::cerr << "[DEBUG] Failed to parse expression: " << trimmedExpr << std::endl;
        variables[variable] = 0; // Assign a default value of 0 if the expression could not be parsed.
    }
}
//----------------------------------------------------------------------------
