#include "Command.h" // Include the declaration of the Command class

//-----------------------------------------
// Do not modify this file
//-----------------------------------------

Command::Command() {
    // Default constructor definition
    // As there's no custom initialization needed for this base class, it's left empty.
}

Command::~Command() {
    // Virtual destructor definition
    // Even though it does nothing, defining it allows for proper cleanup of derived objects.
}

