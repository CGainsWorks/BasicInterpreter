#ifndef PRINT_COMMAND_H // Include guard to prevent multiple inclusions.
#define PRINT_COMMAND_H

#include "Command.h" // Includes the base Command class.
#include <string> // Includes the standard string class for handling the argument.
#include <map> // Includes the map container for accessing variables.

// Defines the PrintCommand class which inherits from the Command base class.
class PrintCommand : public Command {
    std::string argument; // The argument to print; could be a variable name or a literal string.
    std::map<std::string, double>& variables; // Reference to the map of variables managed by the Program.

public:
    // Constructor that takes an argument to print and a reference to the variables map.
    PrintCommand(const std::string& arg, std::map<std::string, double>& vars);
    
    // Override the run method from the Command base class.
    void run() override; // This method implements the print functionality.
};

#endif // PRINT_COMMAND_H

