#include "Goto.h"
#include "Program.h" // Include if you need to reference static members or methods of Program

GotoCommand::GotoCommand(int line) : targetLineNumber(line) {} 
// Constructor initializes the targetLineNumber with the provided line number.

void GotoCommand::run() {
    auto it = Program::lineToCommandIndex.find(targetLineNumber); 
    // Attempts to find the target line number in the static map lineToCommandIndex of Program class.
    
    if (it != Program::lineToCommandIndex.end()) {
        Program::currentCommandIndex = it->second - 1; 
        // If found, sets the static currentCommandIndex of Program class to the corresponding command index,
        // adjusted for zero-based indexing. This is where the "jump" happens.
        
//        std::cout << "Jumping to line: " << targetLineNumber << std::endl; // Optional debugging message
    } else {
        std::cerr << "GOTO target line " << targetLineNumber << " not found." << std::endl; 
        // Error message if the target line number does not exist in the map.
    }
}

