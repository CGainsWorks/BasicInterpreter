#ifndef BASIC_INPUT_H // If BASIC_INPUT_H is not defined yet,
#define BASIC_INPUT_H // define it to ensure this file is only included once.

#include "Command.h" // Include the base Command class definition.

// Define the InputCommand class that inherits from Command. It's designed for input operations.
class InputCommand : public Command {
    std::string variable; // Holds the name of the variable to store the input.
    std::map<std::string, double>& variables; // Reference to a map holding variable names and values.

public:
    // Constructor. Takes a variable name and a reference to the variables map.
    InputCommand(const std::string& var, std::map<std::string, double>& vars);

    // Overrides the run method from Command. Defines the input operation's execution.
    void run() override;
};

#endif //BASIC_INPUT_H

