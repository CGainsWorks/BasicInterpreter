#ifndef COMMAND_H_ // Begin of the include guard
#define COMMAND_H_

// This line prevents the redefinition error by ensuring that
// the compiler includes this file only once in the compilation process.

#include <iostream> // Include the IO stream library for input/output operations
class Program; // Forward declaration of the Program class

// This is used to inform the compiler about the existence of the Program class,
// so it can be referenced in this or other included files before its actual declaration.

class Command {
public:
    Command(); // Default constructor declaration
    virtual ~Command(); // Virtual destructor declaration
    // The virtual destructor ensures that derived class destructors are called correctly.

    virtual void run() = 0; // Pure virtual function declaration
    // This makes Command an abstract class, meaning it cannot be instantiated directly.
    // Derived classes must provide an implementation for the run() function.
};

#endif /* COMMAND_H_ */
// End of the include guard

